var Abschlussaufgabe;
(function (Abschlussaufgabe) {
    class Semesteraufgabe {
        constructor(_x, _y, _color) {
            this.x = _x;
            this.y = _y;
            this.color = _color;
        }
        update() {
            this.draw();
        }
        draw() { }
        ;
    }
    Abschlussaufgabe.Semesteraufgabe = Semesteraufgabe;
})(Abschlussaufgabe || (Abschlussaufgabe = {}));
//# sourceMappingURL=Superclass.js.map